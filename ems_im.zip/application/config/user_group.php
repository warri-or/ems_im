<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//user group
$config['USER_GROUP_SUPER'] = 1;
$config['USER_GROUP_ADMIN'] = 2;
