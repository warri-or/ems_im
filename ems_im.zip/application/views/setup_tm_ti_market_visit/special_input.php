<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    $CI = & get_instance();
        ?>
        <input name="data[<?php echo $day_no; ?>][<?php echo $shift_id; ?>][special]" type="text" class="form-control integer_type_positive" value="">
